package com.geekster.assignment.UserManagement.Model;

public enum Type {
    ADMIN,INTERNAL,EXTERNAL
}