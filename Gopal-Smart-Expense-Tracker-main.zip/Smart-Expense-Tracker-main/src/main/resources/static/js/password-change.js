/**
 * 
 */

/* function validate() {
    var pass1 = document.getElementById('password');
    var pass2 = document.getElementById('ccpassword');

    if (pass1.value != pass2.value) {
        pass2.focus();
        alert("Passwords don't match");
        return false;
    }
    return true;

}*/