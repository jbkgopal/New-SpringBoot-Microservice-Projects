import model.*;
class App
{
    public static void main(String[] args) {
        Home ob =new Home();
    }
}